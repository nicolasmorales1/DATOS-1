package listasenlazadas;

import java.util.Scanner;

public class ListasEnlazadas {

    static Scanner leer = new Scanner(System.in);
    static Nodo PTR = null;

    static void crearCola() {
        int op;
        Nodo z = PTR;
        boolean sw;
        do {
            System.out.println("Digite info del nodo: ");
            int num = leer.nextInt();
            if (z == null) {
                z = new Nodo(num);
            } else {
                Nodo q = z;
                while (q.getLink() != null) {
                    q = q.getLink();
                }
                q.setLink(new Nodo(num));
            }
            System.out.println("Quiere insertar mas nodos 1-Si, 0-No");
            op = leer.nextInt();
            sw = (op == 1);
        } while (sw);
        PTR = z;
    }

    static void crearListaOrdenada() {
        int masNodos = 1, num;
        Nodo p = PTR;
        do {
            int sw = 0;
            Nodo antp = null, q = null;
            p = PTR;
            System.out.println("Digite info del nodo: ");
            num = leer.nextInt();
            q = new Nodo(num);
            if (PTR == null) {
                PTR = q;
            } else {
                while ((p != null) && (sw == 0)) {
                    if (p.getNum() > q.getNum()) {
                        q.setLink(p);
                        if (antp != null) {
                            antp.setLink(q);
                        } else {
                            PTR = q;
                        }
                        sw = 1;
                    } else if (p.getNum() == q.getNum()) {
                        sw = 2;
                        System.out.println("No puden haber repeticiones");
                    } else {
                        antp = p;
                        p = p.getLink();
                    }
                }
                if (sw == 0) {
                    antp.setLink(q);
                    q.setLink(null);
                } 
            }
            System.out.println("Desea ingresar mas nodos 1-Si, 0-No");
            masNodos = leer.nextInt();
        } while (masNodos == 1);
        
    }

    static void pruebaCola() {
        PTR = null;
        Nodo z = PTR;
        for (int i = 0; i < 7; i++) {
            System.out.println("Digite info del nodo: ");
            int num = leer.nextInt();
            if (z == null) {
                z = new Nodo(num);
            } else {
                Nodo q = z;
                while (q.getLink() != null) {
                    q = q.getLink();
                }
                q.setLink(new Nodo(num));
            }
        }
        PTR = z;
    }

    static void mostrar(Nodo PTR) {
        Nodo q = PTR;
        while (q != null) {
            System.out.println(q.getNum());
            q = q.getLink();
        }
    }

    static void eliminar(int info) {
        Nodo p = PTR, antp = null;
        if (PTR != null) {
            while (p.getNum() != info && p.getLink() != null) {
                antp = p;
                p = p.getLink();
            }
            if (p.getNum() == info) {
                if (p == PTR) {
                    PTR = p.getLink();
                    p.setLink(null);
                } else {
                    antp.setLink(p.getLink());
                    p.setLink(null);
                }
            } else {
                System.out.println("No se encontro el elemento con la informacion " + info);
            }
        } else {
            System.out.println("Lista vacia!");
        }
    }

    static void ejercicio() {

        Nodo p = PTR, antp = new Nodo(0), q = new Nodo(0);

        if (PTR != null) {
            while (p != null) {
                if (p.getNum() == 0) {
                    q.setNum(200);
                    q.setLink(p);
                    if (antp.getLink() != null) {
                        antp.setLink(q);
                    } else {
                        PTR = q;
                    }
                    antp = p;
                    p = p.getLink();
                } else if (p.getNum() < 0) {
                    if (p.getLink() != null) {
                        if (antp.getLink() != null) {
                            antp.setLink(p.getLink());
                            p.setLink(null);
                            p = antp.getLink();
                        } else {
                            antp = p;
                            p = p.getLink();
                            antp.setLink(null);
                            PTR = p;
                        }
                    } else if (antp.getLink() != null) {
                        antp.setLink(null);
                        p = null;
                    } else {
                        PTR = null;
                        p = null;
                    }
                } else { //positivo
                    q.setNum(100);
                    if (p.getLink() != null) {
                        q.setLink(p.getLink());
                        p.setLink(q);
                        antp = q;
                        p = q.getLink();
                    } else {
                        p.setLink(q);
                        q.setLink(null);
                        p = null;
                    }
                }
                q = new Nodo(0);
            }
        } else {
            System.out.println("Lista vacia!");
        }

    }

    public static void main(String[] args) {
        int op;
        do {
            System.out.println("Opciones:\n"
                    + "1. Crear Cola\n"
                    + "2. Mostrar Lista\n"
                    + "3. Eliminar\n"
                    + "4. Ejercicio (Positivo inserta despues 100, Negativo elimina, 0 inserta antes 200)"
                    + "0. Salir");
            System.out.println("OPCION: ");
            op = leer.nextInt();
            switch (op) {
                case 1:
                    //crearCola();
                    pruebaCola();
                    //crearListaOrdenada();
                    break;
                case 2:
                    mostrar(PTR);
                    break;
                case 3:
                    System.out.println("Digite elemento a eliminar: ");
                    int info = leer.nextInt();
                    eliminar(info);
                    break;
                case 4:
                    ejercicio();
                    break;
                default:
                    op = 0;
                    break;
            }
        } while (op != 0);

    }
}
