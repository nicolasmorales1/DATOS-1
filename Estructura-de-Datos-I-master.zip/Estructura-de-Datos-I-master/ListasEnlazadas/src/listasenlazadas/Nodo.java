/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasenlazadas;

/**
 *
 * @author Estudiante
 */
public class Nodo {
    private int num;
    private Nodo link;

    public Nodo(int num) {
        this.num = num;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Nodo getLink() {
        try {
        return link;
        } catch (Exception ex){
            return null;
        }
    }

    public void setLink(Nodo link) {
        this.link = link;
    }
   
    
}
