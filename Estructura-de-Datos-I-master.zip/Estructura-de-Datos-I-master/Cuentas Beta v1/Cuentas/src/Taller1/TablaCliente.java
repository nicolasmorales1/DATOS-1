/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Taller1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Estudiante
 */
public class TablaCliente extends javax.swing.JFrame {

    String rutaCliente;
    int total;

    public TablaCliente() {
        initComponents();
        this.rutaCliente = "./Clientes.txt";
        this.total = 0;
        this.verificarArchivo();
        this.leerCliente();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void verificarArchivo() {
        try {
            File archivoCliente = new File(this.rutaCliente);
            if (!archivoCliente.exists()) {
                archivoCliente.createNewFile();
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void leerCliente() {
        try {
            File archivoCliente = new File(this.rutaCliente);
            FileReader lector = new FileReader(archivoCliente);
            BufferedReader br = new BufferedReader(lector);
            String registro;
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split("\\|");
                String cedula = campos[0];
                String nombre = campos[1];
                int saldo = Integer.parseInt(campos[2]);
                this.agregarATabla(cedula, nombre, saldo);
                this.total += saldo;
            }
            br.close();
            lector.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }
        this.lTotal.setText("Total: " + this.total);
    }

    private void agregarATabla(String cedula, String nombre, int saldo) {
        DefaultTableModel modelo = (DefaultTableModel) this.tClien.getModel();
        modelo.addRow(new Object[]{cedula, nombre, saldo});
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tClien = new javax.swing.JTable();
        b2Reg = new javax.swing.JButton();
        lSalt = new javax.swing.JLabel();
        lTotal = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tClien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cedula", "Nombre", "Saldo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tClien);
        if (tClien.getColumnModel().getColumnCount() > 0) {
            tClien.getColumnModel().getColumn(0).setResizable(false);
            tClien.getColumnModel().getColumn(1).setResizable(false);
            tClien.getColumnModel().getColumn(2).setResizable(false);
        }

        b2Reg.setText("Regresar");
        b2Reg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2RegActionPerformed(evt);
            }
        });

        lTotal.setText("Null");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(b2Reg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lSalt)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(200, 200, 200)
                .addComponent(lTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lTotal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(b2Reg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lSalt))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b2RegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2RegActionPerformed
        new Menu();
        this.dispose();
    }//GEN-LAST:event_b2RegActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b2Reg;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lSalt;
    private javax.swing.JLabel lTotal;
    private javax.swing.JTable tClien;
    // End of variables declaration//GEN-END:variables
}
