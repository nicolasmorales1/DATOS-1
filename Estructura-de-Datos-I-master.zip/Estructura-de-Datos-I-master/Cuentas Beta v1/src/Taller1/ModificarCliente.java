package Taller1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class ModificarCliente extends javax.swing.JFrame {

    String rutaCliente, rutaModificacion;

    public ModificarCliente() {
        initComponents();
        this.rutaCliente = "./Clientes.txt";
        this.rutaModificacion = "./Modificacion.txt";
        this.verificarArchivo();
    }

    private void verificarArchivo() {
        //try {
        File archivoCliente = new File(this.rutaCliente);
        if (!archivoCliente.exists()) {
            JOptionPane.showMessageDialog(null, "Cree primero un archivo");
            new Menu();
            this.dispose();
        } else {
            File archivoModificacion = new File(this.rutaModificacion);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        }
        /*
         * } catch (IOException ex) { System.err.println(ex); }
         */
    }

    private void modificarCliente(String cedula, String consigna, String retiro) {
        try {
            String linea, caracter = "|", ced;
            int aviso = 0, x, sal;
            File archivoCliente = new File(this.rutaCliente);
            File archivoModificacion = new File(this.rutaModificacion);
            FileReader fr = new FileReader(archivoCliente);
            BufferedReader br = new BufferedReader(fr);
            FileWriter escritor = new FileWriter(archivoModificacion);
            PrintWriter impresor = new PrintWriter(escritor);
            while ((linea = br.readLine()) != null) {
                //ced = accederCampo(linea, 1);
                String[] campos = linea.split("\\|");
                ced = campos[0];
                if (cedula.equals(ced)) {
                    //sal = Integer.parseInt(accederCampo(linea, 3));
                    sal = Integer.parseInt(campos[2]);
                    if (!consigna.equals("")) {
                        x = Integer.parseInt(consigna);
                        sal = sal + x;
                        aviso = 1;
                    }
                    if (!retiro.equals("")) {
                        x = Integer.parseInt(retiro);
                        if (x < sal) {
                            sal = sal - x;
                            aviso = 1;
                        } else {
                            JOptionPane.showMessageDialog(null, "Fondos insuficinetes para retirar");
                        }
                    }
                    if (aviso == 1) {
                        //impresor.println(accederCampo(linea, 1) + caracter + accederCampo(linea, 2) + caracter + sal);
                        impresor.println(campos[0] + caracter + campos[1] + caracter + sal);
                        JOptionPane.showMessageDialog(null, "Modificacion exitosa");
                    } else {
                        aviso = 1;
                        JOptionPane.showMessageDialog(null, "Modificacion fallida, revise los datos ingresados");
                        impresor.println(linea);
                    }
                } else {
                    impresor.println(linea);
                }
            }
            impresor.close();
            escritor.close();
            br.close();
            fr.close();
            archivoCliente.delete();
            archivoModificacion.renameTo(archivoCliente);
            if (aviso == 0) {
                JOptionPane.showMessageDialog(null, "Modificacion fallida, revise los datos ingresados");
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private String accederCampo(String s, int campo) {
        String letra, tcampo = "";
        int contador = 1, i = 0;
        while ((contador <= campo) && (s.length() > i)) {
            letra = s.substring(i, i + 1);
            if (letra.equals("|")) {
                contador = contador + 1;
            } else if (contador == campo) {
                tcampo = tcampo + letra;
            }
            i++;
        }
        return tcampo;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l2Ced = new javax.swing.JLabel();
        t2Ced = new javax.swing.JTextField();
        lCons = new javax.swing.JLabel();
        tCon = new javax.swing.JTextField();
        lRet = new javax.swing.JLabel();
        tRet = new javax.swing.JTextField();
        bMod = new javax.swing.JButton();
        b2Reg = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        l2Ced.setText("Cedula");

        lCons.setText("Consignar");

        lRet.setText("Retirar");

        bMod.setText("Modificar");
        bMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModActionPerformed(evt);
            }
        });

        b2Reg.setText("Regresar");
        b2Reg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2RegActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bMod, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(l2Ced)
                            .addComponent(lCons))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tRet, javax.swing.GroupLayout.DEFAULT_SIZE, 319, Short.MAX_VALUE)
                            .addComponent(t2Ced)
                            .addComponent(tCon)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lRet)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(b2Reg, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l2Ced)
                    .addComponent(t2Ced, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lCons))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lRet)
                    .addComponent(tRet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(bMod)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(b2Reg)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModActionPerformed
        String cedula = this.t2Ced.getText();
        String consigna = this.tCon.getText();
        String retiro = this.tRet.getText();
        this.modificarCliente(cedula, consigna, retiro);
        this.t2Ced.setText("");
        this.tCon.setText("");
        this.tRet.setText("");
    }//GEN-LAST:event_bModActionPerformed

    private void b2RegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2RegActionPerformed
        new Menu();
        this.dispose();
    }//GEN-LAST:event_b2RegActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b2Reg;
    private javax.swing.JButton bMod;
    private javax.swing.JLabel l2Ced;
    private javax.swing.JLabel lCons;
    private javax.swing.JLabel lRet;
    private javax.swing.JTextField t2Ced;
    private javax.swing.JTextField tCon;
    private javax.swing.JTextField tRet;
    // End of variables declaration//GEN-END:variables
}
