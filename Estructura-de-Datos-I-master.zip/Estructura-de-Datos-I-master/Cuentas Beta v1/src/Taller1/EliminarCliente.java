package Taller1;

import java.io.*;
import javax.swing.JOptionPane;

public class EliminarCliente extends javax.swing.JFrame {

    String rutaCliente, rutaModificacion;

    public EliminarCliente() {
        initComponents();
        this.rutaCliente = "./Clientes.txt";
        this.rutaModificacion = "./Modificacion.txt";
        this.verificarArchivo();
    }

    private void verificarArchivo() {
        //try {
        File archivoCliente = new File(this.rutaCliente);
        if (!archivoCliente.exists()) {
            JOptionPane.showMessageDialog(null, "Cree primero un archivo");
            new Menu();
            this.dispose();
        } else {
            File archivoModificacion = new File(this.rutaModificacion);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        }
    }

    private void eliminarCliente(String cedula) {
        try {
            String linea, ced;
            int aviso = 0;
            File archivoCliente = new File(this.rutaCliente);
            File archivoModificacion = new File(this.rutaModificacion);
            FileReader fr = new FileReader(archivoCliente);
            BufferedReader br = new BufferedReader(fr);
            FileWriter escritor = new FileWriter(archivoModificacion);
            PrintWriter impresor = new PrintWriter(escritor);
            while ((linea = br.readLine()) != null) {
                String[] campos = linea.split("\\|");
                ced = campos[0];
                if (!cedula.equals(ced)) {
                    impresor.println(linea);
                } else {
                    aviso = 1;
                }
            }
            impresor.close();
            escritor.close();
            br.close();
            fr.close();
            archivoCliente.delete();
            archivoModificacion.renameTo(archivoCliente);
            if (aviso == 0) {
                JOptionPane.showMessageDialog(null, "Cedula no encontrada, revise los datos ingresados");
            }else {
                JOptionPane.showMessageDialog(null, "Cliente eliminado exitosamente");
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        t3Ced = new javax.swing.JTextField();
        l3Ced = new javax.swing.JLabel();
        b3Reg = new javax.swing.JButton();
        bElim = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        l3Ced.setText("Cedula");

        b3Reg.setText("Regresar");
        b3Reg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3RegActionPerformed(evt);
            }
        });

        bElim.setText("Eliminar");
        bElim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bElimActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(l3Ced)
                        .addGap(18, 18, 18)
                        .addComponent(t3Ced))
                    .addComponent(bElim, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(b3Reg, javax.swing.GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l3Ced)
                    .addComponent(t3Ced, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(bElim)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(b3Reg)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b3RegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3RegActionPerformed
        new Menu();
        this.dispose();
    }//GEN-LAST:event_b3RegActionPerformed

    private void bElimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bElimActionPerformed
        String cedula = this.t3Ced.getText();
        this.eliminarCliente(cedula);
        this.t3Ced.setText("");
    }//GEN-LAST:event_bElimActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b3Reg;
    private javax.swing.JButton bElim;
    private javax.swing.JLabel l3Ced;
    private javax.swing.JTextField t3Ced;
    // End of variables declaration//GEN-END:variables
}
