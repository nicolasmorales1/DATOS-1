package Taller1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class EditarCliente extends javax.swing.JFrame {

    private final String rutaCliente;

    public EditarCliente() {
        initComponents();

        this.rutaCliente = "./Clientes.txt";

        this.verificarArchivos();

        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void verificarArchivos() {
        try {
            File archivoCliente = new File(this.rutaCliente);
            if (!archivoCliente.exists()) {
                archivoCliente.createNewFile();
            }
        } catch (IOException ex) {
            System.err.println("Hubo un error: " + ex);
        }
    }

    private void leerCliente(String cedula) {
        FileReader archivo;
        BufferedReader br;
        String registro;
        try {
            archivo = new FileReader(this.rutaCliente);
            br = new BufferedReader(archivo);
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split("\\|");
                if (cedula.equals(campos[0])) {
                    String nombre = campos[1];
                    int salario = Integer.parseInt(campos[2]);
                    this.mostrarCliente(nombre, salario);
                }
            }
            br.close();
            archivo.close();
        } catch (IOException ex) {
            System.err.println("Hubo un error: " + ex);
        }
    }

    private void mostrarCliente(String nombre, int salario) {
        this.tfNombre.setText(nombre);
        this.tfSaldo.setText(salario + "");
    }
    
    private void editar(){
        this.btnBuscar.setText("Editar");
        this.tfCedula.setEnabled(false);
        this.tfNombre.setEnabled(true);
        this.tfSaldo.setEnabled(true);
    }
    
    private void buscar(){
        this.btnBuscar.setText("Buscar");
        this.tfCedula.setEnabled(true);
        this.tfNombre.setEnabled(false);
        this.tfSaldo.setEnabled(false);
        this.tfCedula.setText("");
        this.tfNombre.setText("");
        this.tfSaldo.setText("");
    }
    
    private void editarCliente(String cedulaEditar, String nombreNuevo, int saldoNuevo) {
        String rutaCopia = "./ClientesCopia.txt";
        FileReader archivoLeer;
        BufferedReader br;
        String registro;
        try {
            File archivoClienteCopia = new File(rutaCopia);
            archivoClienteCopia.createNewFile();
            archivoLeer = new FileReader(this.rutaCliente);
            br = new BufferedReader(archivoLeer);
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split("\\|");
                String cedula = campos[0];
                String nombre = campos[1];
                int saldo = Integer.parseInt(campos[2]);
                if (!cedula.equals(cedulaEditar)) {
                    this.guardarClienteCopia(cedula, nombre, saldo, rutaCopia);
                } else {
                    this.guardarClienteCopia(cedula, nombreNuevo, saldoNuevo, rutaCopia);
                }
            }
            
            br.close();
            archivoLeer.close();

            File viejo = new File(this.rutaCliente);
            viejo.delete();
            this.renombrar("Clientes", rutaCopia);
            JOptionPane.showMessageDialog(null, "Guardado con exito");

        } catch (IOException ex) {
            System.err.println("Hubo un error: " + ex);
        }
    }

    private void renombrar(String nuevoNombre, String ruta) {
        File viejo = new File(ruta);
        File nuevo = new File(viejo.getParent(), nuevoNombre + ".txt");
        viejo.renameTo(nuevo);
    }

    private void guardarClienteCopia(String cedula, String nombre, int saldo, String ruta) {
        try {
            File archivo = new File(ruta);
            FileWriter fr = new FileWriter(archivo, true);
            PrintWriter pw = new PrintWriter(fr);
            pw.println(cedula + "|" + nombre + "|" + saldo);
            pw.close();
            fr.close();
        } catch (IOException ex) {
            System.err.println("Hubo un error: " + ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tfNombre = new javax.swing.JTextField();
        tfCedula = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tfSaldo = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Nombre");

        tfNombre.setEnabled(false);

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Cedula");

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Saldo");

        tfSaldo.setEnabled(false);

        btnBuscar.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnVolver.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfSaldo))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfCedula))
                    .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tfCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnBuscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String cedula = this.tfCedula.getText();
        if(this.btnBuscar.getText().equals("Editar")){
            String nombre = this.tfNombre.getText();
            int saldo = Integer.parseInt(this.tfSaldo.getText());
            this.editarCliente(cedula, nombre, saldo);
            this.buscar();
        } else {
            this.editar();
            this.leerCliente(cedula);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        new Menu();
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField tfCedula;
    private javax.swing.JTextField tfNombre;
    private javax.swing.JTextField tfSaldo;
    // End of variables declaration//GEN-END:variables
}
