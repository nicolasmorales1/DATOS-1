package Taller1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class BorrarCliente extends javax.swing.JFrame {

    String rutaCliente;
    
    public BorrarCliente() {
        initComponents();
        this.rutaCliente = "./Clientes.txt";
        this.verificarArchivo();
        this.leerCliente();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void verificarArchivo() {
        try {
            File archivoCliente = new File(this.rutaCliente);
            if (!archivoCliente.exists()) {
                archivoCliente.createNewFile();
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void leerCliente() {
        DefaultTableModel dtm = (DefaultTableModel) this.jTable1.getModel();
        dtm.setRowCount(0);
        
        File archivoCliente = new File(this.rutaCliente);
        FileReader lector;
        BufferedReader br;
        String registro;
        try {
            lector = new FileReader(archivoCliente);
            br = new BufferedReader(lector);
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split("\\|");
                String cedula = campos[0];
                String nombre = campos[1];
                int saldo = Integer.parseInt(campos[2]);
                this.agregarATabla(cedula, nombre, saldo);
            }
            br.close();
            lector.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void agregarATabla(String cedula, String nombre, int saldo) {
        DefaultTableModel modelo = (DefaultTableModel) this.jTable1.getModel();
        modelo.addRow(new Object[]{cedula, nombre, saldo});
    }
    
    private void eliminarCliente(String cedulaABorrar) {
        String rutaCopia = "./Copia.txt";
        File archivoCliente = new File(this.rutaCliente);
        FileReader lector;
        BufferedReader br;
        String registro;
        try {
            lector = new FileReader(archivoCliente);
            br = new BufferedReader(lector);
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split("\\|");
                String cedula = campos[0];
                String nombre = campos[1];
                int saldo = Integer.parseInt(campos[2]);
                if(!cedulaABorrar.equals(cedula)){
                    this.guardarCliente(cedula, nombre, saldo + "", rutaCopia);
                }
            }
            br.close();
            lector.close();
            
            JOptionPane.showMessageDialog(null, "Eliminado con exito");
        } catch (IOException ex) {
            System.err.println(ex);
        }
        
        File viejo = new File(this.rutaCliente);
        viejo.delete();
        viejo = new File(rutaCopia);
        File nuevo = new File(this.rutaCliente);
        viejo.renameTo(nuevo);
    }

    private void guardarCliente(String cedula, String nombre, String saldo, String ruta){
        try {
            File archivoCliente = new File(ruta);
            if (!archivoCliente.exists()) {
                archivoCliente.createNewFile();
            }
            FileWriter escritor = new FileWriter(archivoCliente, true);
            PrintWriter impresor = new PrintWriter(escritor);
            String caracter = "|";
            impresor.println(cedula + caracter + nombre + caracter + saldo);
            impresor.close();
            escritor.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        tfCedula = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cedula", "Nombre", "Saldo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(1).setResizable(false);
        }

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cedula");

        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 527, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfCedula))
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new Menu();
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String cedula = this.tfCedula.getText();
        this.eliminarCliente(cedula);
        this.leerCliente();
    }//GEN-LAST:event_jButton2ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField tfCedula;
    // End of variables declaration//GEN-END:variables
}
