

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MostrarPromedio extends javax.swing.JFrame {

    String rutaEstudiante;
    float total = 0, contador = 0;

    public MostrarPromedio() {
        initComponents();
        this.rutaEstudiante = "./Estudiante.txt";
        this.verificarArchivo();
    }

    private void verificarArchivo() {
        File archivoEstudiante = new File(this.rutaEstudiante);
        if (archivoEstudiante.exists()) {
            this.mostrarPromedio();
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Ingrese estudiantes primero");
            this.dispose();
            new Menu();
        }

    }

    private void mostrarPromedio() {
        try {
            File archivoEstudiante = new File(this.rutaEstudiante);
            FileReader lector = new FileReader(archivoEstudiante);
            BufferedReader br = new BufferedReader(lector);
            String registro;
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split("\\|");
                String codigo = campos[0];
                String nombre = campos[1];
                float promedio = Float.parseFloat(campos[2]) / Float.parseFloat(campos[3]);
                this.agregarATabla(codigo, nombre, promedio);
                this.total += promedio;
                this.contador += 1;
            }
            br.close();
            lector.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }
        this.lPromG.setText("Promedio General: " + this.total/this.contador);
    }

    private void agregarATabla(String codigo, String nombre, float promedio) {
        DefaultTableModel modelo = (DefaultTableModel) this.tEstudi.getModel();
        modelo.addRow(new Object[]{codigo, nombre, promedio});
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tEstudi = new javax.swing.JTable();
        b2Reg = new javax.swing.JButton();
        lSalt = new javax.swing.JLabel();
        lPromG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tEstudi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre", "Promedio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tEstudi);
        if (tEstudi.getColumnModel().getColumnCount() > 0) {
            tEstudi.getColumnModel().getColumn(0).setResizable(false);
            tEstudi.getColumnModel().getColumn(1).setResizable(false);
            tEstudi.getColumnModel().getColumn(2).setResizable(false);
        }

        b2Reg.setText("Regresar");
        b2Reg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2RegActionPerformed(evt);
            }
        });

        lPromG.setText("Null");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lPromG, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(b2Reg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lSalt)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lPromG)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(b2Reg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lSalt))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b2RegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2RegActionPerformed
        new Menu();
        this.dispose();
    }//GEN-LAST:event_b2RegActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b2Reg;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lPromG;
    private javax.swing.JLabel lSalt;
    private javax.swing.JTable tEstudi;
    // End of variables declaration//GEN-END:variables
}
