

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class CrearEstudiante extends javax.swing.JFrame {

    String rutaNota, rutaEstudiante, rutaModificacion;

    public CrearEstudiante() {
        initComponents();
        this.rutaNota = "./Notas.txt";
        this.rutaEstudiante = "./Estudiante.txt";
        this.rutaModificacion = "./Modificacion.txt";
        this.verificarArchivo();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void verificarArchivo() {
        try {
            File archivoNotas = new File(this.rutaNota);
            File archivoEstudiante = new File(this.rutaEstudiante);
            if (!archivoNotas.exists()) {
                archivoNotas.createNewFile();
            }
            if (!archivoEstudiante.exists()) {
                archivoEstudiante.createNewFile();
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void modificarEstudiante(String codigo, String nombre, String nota) {
        try {
            String linea, cod, caracter = "|";
            float not, x;
            int aviso = 0;
            File archivoEstudiante = new File(this.rutaEstudiante);
            File archivoModificacion = new File(this.rutaModificacion);
            FileReader fr = new FileReader(archivoEstudiante);
            BufferedReader br = new BufferedReader(fr);
            FileWriter escritor = new FileWriter(archivoModificacion);
            PrintWriter impresor = new PrintWriter(escritor);
            while ((linea = br.readLine()) != null) {
                String[] campos = linea.split("\\|");
                cod = campos[0];
                if (codigo.equals(cod)) {
                    aviso = 1;
                    if (!nota.equals("")) {
                        not = Float.parseFloat(campos[2]) + Float.parseFloat(nota);
                        x = Float.parseFloat(campos[3]) + 1;
                        impresor.println(campos[0] + caracter + campos[1] + caracter + not + caracter + x);
                    } else {
                        JOptionPane.showMessageDialog(null, "Modificacion fallida, revise los datos ingresados");
                    }
                } else {
                    impresor.println(linea);
                }
            }
            if (aviso == 0) {
                impresor.println(codigo + caracter + nombre + caracter + nota + caracter + "1");
            }
            impresor.close();
            escritor.close();
            br.close();
            fr.close();
            archivoEstudiante.delete();
            archivoModificacion.renameTo(archivoEstudiante);
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void guardarNota(String codigo, String nombre, String nota) {
        try {
            File archivoNotas = new File(this.rutaNota);
            FileWriter escritor = new FileWriter(archivoNotas, true);
            PrintWriter impresor = new PrintWriter(escritor);
            String caracter = "|";
            impresor.println(codigo + caracter + nombre + caracter + nota);
            this.modificarEstudiante(codigo, nombre, nota);
            impresor.close();
            escritor.close();
            JOptionPane.showMessageDialog(null, "Guardado con exito");
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lCod = new javax.swing.JLabel();
        tCod = new javax.swing.JTextField();
        lNom = new javax.swing.JLabel();
        tNom = new javax.swing.JTextField();
        lNot = new javax.swing.JLabel();
        tNot = new javax.swing.JTextField();
        bCre = new javax.swing.JButton();
        bReg = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lCod.setText("Codigo");

        lNom.setText("Nombre");

        lNot.setText("Nota");

        bCre.setText("Ingresar");
        bCre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCreActionPerformed(evt);
            }
        });

        bReg.setText("Regresar");
        bReg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bRegActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bCre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lCod)
                            .addComponent(lNom))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tNot, javax.swing.GroupLayout.DEFAULT_SIZE, 319, Short.MAX_VALUE)
                            .addComponent(tCod)
                            .addComponent(tNom)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lNot)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(bReg, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lCod)
                    .addComponent(tCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lNom))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lNot)
                    .addComponent(tNot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(bCre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bReg)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bCreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCreActionPerformed
        // TODO add your handling code here:
        String codigo = this.tCod.getText();
        String nombre = this.tNom.getText();
        String nota = this.tNot.getText();
        if ((!codigo.equals("")) && (!nombre.equals("")) && (!nota.equals(""))) {
            this.guardarNota(codigo, nombre, nota);
        } else {
            JOptionPane.showMessageDialog(null, "Escriba Algo");
        }
        this.tCod.setText("");
        this.tNom.setText("");
        this.tNot.setText("");
    }//GEN-LAST:event_bCreActionPerformed

    private void bRegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRegActionPerformed
        // TODO add your handling code here:
        new Menu();
        this.dispose();
    }//GEN-LAST:event_bRegActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bCre;
    private javax.swing.JButton bReg;
    private javax.swing.JLabel lCod;
    private javax.swing.JLabel lNom;
    private javax.swing.JLabel lNot;
    private javax.swing.JTextField tCod;
    private javax.swing.JTextField tNom;
    private javax.swing.JTextField tNot;
    // End of variables declaration//GEN-END:variables
}
